package com.cg.hotelManagement.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class DBUtil {

	private static Connection connHotelManagement;
	
	public static Connection CreateConnection(){
		ResourceBundle resOracle = ResourceBundle.getBundle("oracle");
		
		String url = resOracle.getString("url");
		String username = resOracle.getString("username");
		String password = resOracle.getString("password");
		
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		
		
		connHotelManagement=DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			System.err.println("Problems in connection");
			e.printStackTrace();
		}
		
			
		return connHotelManagement;
		
	}
	public static void closeConnection() throws SQLException{
		if(connHotelManagement != null){
			connHotelManagement.close();
		}
	}
}
