package com.cg.hotelManagement.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.hotelManagement.dto.Hotels;
import com.cg.hotelManagement.dto.UserDetails;
import com.cg.hotelManagement.dto.bookingDetails;
import com.cg.hotelManagement.exception.HotelManagementException;

public class HotelManagementDaoImpl implements IHotelMangementDao {

	private EntityManager entityManager;
	
	public HotelManagementDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}
	
	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
		entityManager.flush();
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}
	
	@Override
	public UserDetails userLogin(String userId) throws HotelManagementException{
		entityManager.getTransaction().begin();
		try{
		UserDetails userDetails=entityManager.find(UserDetails.class,userId);
		entityManager.getTransaction().commit();
		return userDetails;
		}catch(NullPointerException e){
			throw new HotelManagementException("This User Does Not Exist");
		}
		
	}

	@Override
	public void addUser(UserDetails userDetails) {
		entityManager.getTransaction().begin();
		entityManager.persist(userDetails);
		entityManager.getTransaction().commit();
	}

	@Override
	public List<bookingDetails> viewBookingDetailsFromDate(LocalDate date2) {
		int d=date2.getDayOfMonth();
		int y=date2.getYear();
		int m=date2.getMonthValue();
		Date date=new Date(y-1900, m-1, d);
		beginTransaction();
		List<bookingDetails> bookingDetails=new ArrayList<bookingDetails>();
        String querry=new String("select bookingDetails from BookingDetails bookingDetails"+
		                         " where bookingDetails.bookedFrom<=:pDate"+
        		                   " and bookingDetails.bookedTo>=:pDate");	
        TypedQuery<bookingDetails> quer=entityManager.createQuery(querry,bookingDetails.class);
		quer.setParameter("pDate", date);
		return quer.getResultList();
	}

	@Override
	public List<Hotels> searchHotels(String city, double minPrice,
			double maxPrice, int rating) {
			beginTransaction();
			List<bookingDetails> bookingDetails=new ArrayList<bookingDetails>();
	        String querry=new String("select hotel from Hotels hotel"+
			                         " where hotel.city=:pCity and "
			                         + "hotel.avgRatePerNight<=:pMaxPrice and "+
			                         "hotel.avgRatePerNight>=:pMinPrice"+
	        		                   " and hotel.rating>=:pRating");	
	        TypedQuery<Hotels> quer=entityManager.createQuery(querry,Hotels.class);
			quer.setParameter("pMinPrice",minPrice);
			quer.setParameter("pMaxPrice",maxPrice);
			quer.setParameter("pRating",rating);
			quer.setParameter("pCity",city);
			return quer.getResultList();
	}

}
