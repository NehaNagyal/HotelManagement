package com.cg.hotelManagement.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.hotelManagement.dao.HotelManagementDaoImpl;
import com.cg.hotelManagement.dto.Hotels;
import com.cg.hotelManagement.dto.UserDetails;
import com.cg.hotelManagement.dto.bookingDetails;
import com.cg.hotelManagement.exception.HotelManagementException;

public class HotleManagementServiceImpl implements IHotelManagementService {

	HotelManagementDaoImpl hotelManagementDao=new HotelManagementDaoImpl();
	
	public boolean adminLogin(String userName,String password){
		if(userName.equalsIgnoreCase("system") && password.equals("Capgemini123"))
			return true;
		else 
			return false;
	}

	@Override
	public int userLogin(String userName, String Password) throws HotelManagementException {
		UserDetails  userDetails=hotelManagementDao.userLogin(userName);
		try{
		String uId = userDetails.getUserId();
		String pwd= userDetails.getPassword();
		
		if(userName.equalsIgnoreCase("system") && Password.equals("Capgemini123"))
			return 1;
		else 
			return 0;
		}catch(NullPointerException e){
			throw new HotelManagementException("User does not exist");
		}
	}
	

	@Override
	public List<Hotels> viewAllHotels() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<bookingDetails> viewBookingSpecificHotel(String hotelId) {
		return null;
	}

	@Override
	public List<UserDetails> viewGuestListSpecificHotels(String hotellId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<bookingDetails> viewBookingDetailsFromDate(LocalDate date) {
		return hotelManagementDao.viewBookingDetailsFromDate(date);
	}

	@Override
	public List<Hotels> searchHotels(String city, double minPrice,double maxPrice,
			int rating) {
		return hotelManagementDao.searchHotels(city, minPrice, maxPrice, rating);
	}

	@Override
	public int bookHotel() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int bookingStatus() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void addUser(UserDetails userDetails) {
		hotelManagementDao.addUser(userDetails);
	}
}
