package com.cg.hotelManagement.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.hotelManagement.dto.Hotels;
import com.cg.hotelManagement.dto.UserDetails;
import com.cg.hotelManagement.dto.bookingDetails;
import com.cg.hotelManagement.exception.HotelManagementException;

public interface IHotelManagementService {

	public boolean adminLogin(String userName,String password); //will verify username and password of admin and return true or false.(these values are hardcoded in service class.)

	public int userLogin(String userName,String Password) throws HotelManagementException; //this will verify login details of user and return status(0/1) from dao layer.

	public void addUser(UserDetails userDetails);
	
	public List<Hotels> viewAllHotels(); //it will display all hotels from table HOTELS.

	public List<bookingDetails> viewBookingSpecificHotel(String hotelId); //neha
 
	public List<UserDetails> viewGuestListSpecificHotels(String hotellId); //neha

	public List<bookingDetails> viewBookingDetailsFromDate(LocalDate date); //rohitash

	public List<Hotels> searchHotels(String city, double minPrice,double maxPrice,
			int rating); //rohitash

	public int bookHotel(); //take arguments as per needs. //bhuvnesh

	public int bookingStatus(); //take arguments as per needs. //bhuvnesh.

}
